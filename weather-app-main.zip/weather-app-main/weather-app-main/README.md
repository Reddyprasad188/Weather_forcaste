Name: Y.Reddy Prasad
Company: CODTECH IT SOLUTIONS
ID:CT12DS853
Domain: Web Development
Duration: june to August 2024
Mentor: Sravani 

OVERVIEW OF THE PROJECT

PROJECT NAME: The simple and responsive Weather web app
About The Project
A simple and responsive Weather web app built using HTML, CSS and Javascript. It uses <a href="https://openweathermap.org/api">OpenWeatherMap API</a> to fetch Temperature, Weather, Humidity & Wind Speed details. It uses <a href="https://opencagedata.com/api">OpenCageData Geocoder API</a> to fetch exact location coordinates of the user. Background images are fetched from <a href="https://source.unsplash.com">Unsplash</a> and is changed according to the City name. Built based on the 2021 UI trend 'Glassmorphism'.

### Built With

* HTML & CSS
* Javascript
* Vanilla tilt.js library
* OpenWeatherMap & OpenCageData API
